By installing or using this font, you are agree to the Product Usage Agreement:

- This demo font is ONLY FOR PERSONAL USE. NO COMMERCIAL USE ALLOWED!
- Here is the link to purchase full version and commercial license: https://fontbundles.net/bluetype
- You can buy this font for only 1$ on limited time here: https://thehungryjpeg.com/store/bluetype
- For Corporate use you have to purchase Corporate license
- If you need a custom license please contact us: at ardana619@gmail.com
- Any donation are very appreciated. Paypal account for donation: https://paypal.me/bpkedypurwanto
- Follow our instagram for update : @ardana619